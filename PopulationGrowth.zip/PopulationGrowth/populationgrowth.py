print('----------------------------------------')
print('Name: Andrew Klusmeyer')
print('Course: Phython I')
print('Instructor: Dale Musser')
print('Assignment: Population Growth Model Challenge')
print('----------------------------------------\n')

# Prompting user to input the initial population size
initial_population_input = input('Please input the initial population: ')
initial_population = int(initial_population_input)

# Prompting user to input the growth rate percentage
growth_rate_input = input('Please input the growth rate percentage (e.g., 3 for 3%): ')
growth_rate = float(growth_rate_input)

# Prompting user to input the time period in years
time_period_input = input('Please input the time period (in years): ')
time_period = float(time_period_input)

# Testing and Debugging
#print('\n******* DEBUG *******\n')

#print('Value entered for initial population size:', initial_population)
#print('initial_population is', type(initial_population), '\n')

#print('Value entered for growth rate percentage:', growth_rate)
#print('growth_rate is', type(growth_rate), '\n')

#print('Value entered for time period:', time_period)
#print('time_period is', type(time_period))

#print('\n***** END OF DEBUG *****\n')

# Calculating the future population
future_population = initial_population * (1 + (growth_rate / 100))**time_period
print('\nCalculated future population:')
print('The population in', time_period, 'years will be', round(future_population))








