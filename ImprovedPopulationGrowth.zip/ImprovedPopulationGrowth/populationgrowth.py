print('----------------------------------------')
print('Name: Andrew Klusmeyer')
print('Course: Phython I')
print('Instructor: Dale Musser')
print('Assignment: Improved Population Growth Model Challenge')
print('----------------------------------------\n')

while True:
    
    # Getting a valid initial population size from the user
    while True:
        try:
            initial_population = int(input('Please input the initial population: '))
            if initial_population < 0:
                print('Negative population values are not allowed. Please try again.')
                continue
            
        except ValueError:
            print("Only interger values are valid. Please try again.")
            continue
        
        else:
            break
        
    # Getting a valid growth rate from the user
    while True:
        try:
            growth_rate = float(input('Please input the growth rate percentage (e.g., 3 for 3%): '))
            if growth_rate < 0:
                print('Negative growth rates are not allowed. Please try again.')
                continue
            
        except ValueError:
            print("Only numerical values are valid. Please try again.")
            continue

        else:
            break

    # Getting a valid time period from the user
    while True:
        try:
            time_period = int(input('Please input the time period (in years): '))
            if time_period < 0:
                print('Negative time period values are not allowed. Please try again.')
                continue
            
        except ValueError:
            print("Only interger values are valid. Please try again.")
            continue
        
        else:
            break

    # Calculating and displaying future population
    try:
        future_population = initial_population * (1 + (growth_rate / 100))**time_period
    except OverflowError:
        print('Calculated value is too large.')
    else:
        print('The initial population of', initial_population, 'growing at a rate of', growth_rate, 'percent for', time_period, 'years will grow to', round(future_population))

    # Asks user for possibility of another calculation
    while True:
        repeat_value = input('Would you like to perform another calculation? (Y/N)')
        if repeat_value != 'Y' and repeat_value != 'N' and repeat_value != 'y' and repeat_value != 'n':
            print('Invalid answer. Please type Y for yes or N for no.')
            continue
        else:
            break
        
    # Repeating or ending the program
    if repeat_value == 'Y' or repeat_value == 'y':
        continue
    else:
        break



# ************************ Week 2 Version ************************

# Prompting user to input the initial population size
#initial_population_input = input('Please input the initial population: ')
#initial_population = int(initial_population_input)

# Prompting user to input the growth rate percentage
#growth_rate_input = input('Please input the growth rate percentage (e.g., 3 for 3%): ')
#growth_rate = float(growth_rate_input)

# Prompting user to input the time period in years
#time_period_input = input('Please input the time period (in years): ')
#time_period = float(time_period_input)

# Testing and Debugging
#print('\n******* DEBUG *******\n')

#print('Value entered for initial population size:', initial_population)
#print('initial_population is', type(initial_population), '\n')

#print('Value entered for growth rate percentage:', growth_rate)
#print('growth_rate is', type(growth_rate), '\n')

#print('Value entered for time period:', time_period)
#print('time_period is', type(time_period))

#print('\n***** END OF DEBUG *****\n')

# Calculating the future population
#future_population = initial_population * (1 + (growth_rate / 100))**time_period
#print('\nCalculated future population:')
#print('The population in', time_period, 'years will be', round(future_population))








