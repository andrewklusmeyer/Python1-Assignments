print("Name: Andrew Klusmeyer")
print("Age: 22")
print("Education: Persuing BS in Computer Science with a Certificate in Cyber Security")
print("Fun Fact: I'm a Supercar Enthusiast")
